package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import entity.worker;

public class WorkerDao {

private Connection conn;
	
	public WorkerDao(Connection conn) {
		super();
		this.conn=conn;
	}

	public List<worker> getAllWorkers() {
		
		List<worker> list=new ArrayList<worker>();
		worker w=null;
		try {
			String sql="select * from workers order by EntryNumber DESC";
			
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				w=new worker();
				
				w.setId(Integer.parseInt(rs.getString(1)));
				w.setName(rs.getString(2));
				w.setSpecialized(rs.getString(3));
				w.setDescription(rs.getString(4));
				w.setPdate(rs.getTimestamp(5)+"");
				w.setRating(Integer.parseInt(rs.getString(6)));
				list.add(w);
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return list;
		
	}
	
public worker getWorkerById(String id) {
		
		worker w=null;
		try {
			String sql="select * from workers where EntryNumber=?";
			
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				w=new worker();
				
				w.setId(Integer.parseInt(rs.getString(1)));
				w.setName(rs.getString(2));
				w.setSpecialized(rs.getString(3));
				w.setDescription(rs.getString(4));
				w.setPdate(rs.getTimestamp(5)+"");
				w.setRating(Integer.parseInt(rs.getString(6)));
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return w;
		
	}
	
}
