package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import entity.spots;

public class SpotDao {
	
	private Connection conn;
	
	public SpotDao(Connection conn) {
		super();
		this.conn=conn;
	}

	public List<spots> getAllSpots() {
		
		List<spots> list=new ArrayList<spots>();
		spots s=null;
		try {
			String sql="select * from spots order by EntryNumber DESC";
			
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				s=new spots();
				
				s.setId(Integer.parseInt(rs.getString(1)));
				s.setSpot(rs.getString(2));
				s.setParkingSpace(Integer.parseInt(rs.getString(3)));
				s.setDescription(rs.getString(4));
				s.setPdate(rs.getTimestamp(5)+"");
				s.setpph(Integer.parseInt(rs.getString(6)));
				list.add(s);
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return list;
		
	}
	
public spots getSpotById(String id) {
		
		spots s=null;
		try {
			String sql="select * from spots where EntryNumber=?";
			
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				s=new spots();
				
				s.setId(Integer.parseInt(rs.getString(1)));
				s.setSpot(rs.getString(2));
				s.setParkingSpace(Integer.parseInt(rs.getString(3)));
				s.setDescription(rs.getString(4));
				s.setPdate(rs.getTimestamp(5)+"");
				s.setpph(Integer.parseInt(rs.getString(6)));
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return s;
		
	}

public List<spots> getSpotByLoc(String loc){
	List<spots> list=new ArrayList<spots>();
	
	spots s=null;
	
	try {
		
		String sql="select * from spots where spotName=? order by EntryNumber DESC";
		
		PreparedStatement ps=conn.prepareStatement(sql);
		
		ps.setString(1, loc);
		
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			s=new spots();
			
			s.setId(Integer.parseInt(rs.getString(1)));
			s.setSpot(loc);
			s.setParkingSpace(Integer.parseInt(rs.getString(3)));
			s.setDescription(rs.getString(4));
			s.setPdate(rs.getTimestamp(5)+"");
			s.setpph(Integer.parseInt(rs.getString(6)));
			list.add(s);
		}
		
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	return list;
}

public spots getSpotBooked() {
	
	spots s=null;
	try {
		String sql="select * from spotbooked";
		
		PreparedStatement ps=conn.prepareStatement(sql);
		
		ResultSet rs=ps.executeQuery();
		
		while(rs.next()) {
			s=new spots();
			
			s.setId(Integer.parseInt(rs.getString(1)));
			s.setSpot(rs.getString(2));
			s.setParkingSpace(Integer.parseInt(rs.getString(3)));
			s.setDescription(rs.getString(4));
			s.setPdate(rs.getTimestamp(5)+"");
			s.setpph(Integer.parseInt(rs.getString(6)));
		}
		
//		String sql1="truncate table spotbooked";
//		PreparedStatement ps1=conn.prepareStatement(sql1);
//		ps1.executeUpdate();
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	
	
	return s;
	
	
}

}
