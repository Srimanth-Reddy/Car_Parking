package promocode;

import java.security.SecureRandom;
import java.util.Random;

public class procod {
	
	public String generatepromoCode(){
			   
		     char[] chars = "abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*~".toCharArray();
		        StringBuilder sb = new StringBuilder();
		        Random random = new SecureRandom();
		        for (int i = 0; i < 10; i++) {
		            char c = chars[random.nextInt(chars.length)];
		            sb.append(c);
		        }
		        String output = sb.toString();
		        System.out.println(output);
		        return output ;
	
		}	
	}
