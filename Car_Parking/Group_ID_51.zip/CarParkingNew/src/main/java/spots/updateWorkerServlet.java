package spots;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import entity.worker;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class updateSpotServlet
 */
public class updateWorkerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public updateWorkerServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String entrynum=request.getParameter("id");
		String name=request.getParameter("name");
		String spec=request.getParameter("spec");
		String desc=request.getParameter("desc");
		String rating=request.getParameter("rating");
		
		PreparedStatement stmt;
		Connection con;
		RequestDispatcher rd;
		
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/carparking","root","root");
			String sql1="update workers set Name=?,specialized=?,description=?,pdate=now(),rating=? where EntryNumber=?";
			
			
			stmt=con.prepareStatement(sql1);
			
			stmt.setString(1,name);
			stmt.setString(2,spec);
			stmt.setString(3,desc);
			stmt.setString(4,rating);
			stmt.setString(5, entrynum);
		
			stmt.executeUpdate();
			
			worker w=new worker();
			w.setId(Integer.parseInt(entrynum));
			w.setName(name);
			w.setSpecialized(spec);
			w.setDescription(desc);
			w.setRating(Integer.parseInt(rating));
			
			rd=request.getRequestDispatcher("view_worker.jsp");
			rd.forward(request, response);
			
		} 
		catch (Exception e){
			e.printStackTrace();
		}
	}

}
