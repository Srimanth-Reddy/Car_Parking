package spots;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import entity.worker;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class postSpotServlet
 */
public class postWorkerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public postWorkerServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String entrynum=request.getParameter("entrynum");
		String name=request.getParameter("name");
		String spec=request.getParameter("spec");
		String desc=request.getParameter("desc");
		String rating=request.getParameter("rating");
		
		PreparedStatement stmt;
		Connection con;
		RequestDispatcher rd;
		
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/carparking","root","root");
			String sql1="insert into workers(EntryNumber, Name, specialized, description,rating) values(?,?,?,?,?)";
			
			
			stmt=con.prepareStatement(sql1);
			stmt.setString(1,entrynum);
			stmt.setString(2,name);
			stmt.setString(3,spec);
			stmt.setString(4,desc);
			stmt.setString(5, rating);
		
			stmt.executeUpdate();
			
			worker w=new worker();
			w.setId(Integer.parseInt(entrynum));
			w.setName(name);
			w.setSpecialized(spec);
			w.setDescription(desc);
			w.setRating(Integer.parseInt(rating));
			
			rd=request.getRequestDispatcher("post_worker.jsp");
			rd.forward(request, response);
			
		} 
		catch (Exception e){
			e.printStackTrace();
		}
		
	}

}
