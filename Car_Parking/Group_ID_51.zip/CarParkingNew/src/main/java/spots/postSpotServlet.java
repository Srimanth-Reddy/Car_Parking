package spots;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import entity.spots;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class postSpotServlet
 */
public class postSpotServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public postSpotServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String entrynum=request.getParameter("entrynum");
		String spot=request.getParameter("spot");
		String space=request.getParameter("space");
		String desc=request.getParameter("desc");
		String pph=request.getParameter("pph");
		
		PreparedStatement stmt;
		Connection con;
		RequestDispatcher rd;
		
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/carparking","root","root");
			String sql1="insert into spots(EntryNumber, spotName, spaceavail, description,priceperhour) values(?,?,?,?,?)";
			
			
			stmt=con.prepareStatement(sql1);
			stmt.setString(1,entrynum);
			stmt.setString(2,spot);
			stmt.setString(3,space);
			stmt.setString(4,desc);
			stmt.setString(5, pph);
		
			stmt.executeUpdate();
			
			spots s=new spots();
			s.setId(Integer.parseInt(entrynum));
			s.setSpot(spot);
			s.setParkingSpace(Integer.parseInt(space));
			s.setDescription(desc);
			s.setpph(Integer.parseInt(pph));
			
			rd=request.getRequestDispatcher("post_spot.jsp");
			rd.forward(request, response);
			
		} 
		catch (Exception e){
			e.printStackTrace();
		}
		
	}

}
