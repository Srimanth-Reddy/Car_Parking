package entity;

public class User {

		private int id;
		private String fname;
		private String lname;
		private String uname;
		private String email;
		private String password;
		private String carRegNo;
		private String mobnum;
		private String resadd;
		private String role;
		private String freq=null;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getFname() {
			return fname;
		}
		public void setFname(String fname) {
			this.fname = fname;
		}
		public String getLname() {
			return lname;
		}
		public void setLname(String lname) {
			this.lname = lname;
		}
		public String getUname() {
			return uname;
		}
		public void setUname(String uname) {
			this.uname = uname;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getCarRegNo() {
			return carRegNo;
		}
		public void setCarRegNo(String carRegNo) {
			this.carRegNo = carRegNo;
		}
		public String getMobnum() {
			return mobnum;
		}
		public void setMobnum(String string) {
			this.mobnum = string;
		}
		public String getResadd() {
			return resadd;
		}
		public void setResadd(String resadd) {
			this.resadd = resadd;
		}
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		public String getfreq() {
			return freq;
		}
		public void setfreq(String freq) {
			this.freq = freq;
		}
		public User(String fname, String lname, String uname, String email, String password, String carRegNo,
				String mobnum, String resadd, String role, String freq) {
			super();
			this.fname = fname;
			this.lname = lname;
			this.uname = uname;
			this.email = email;
			this.password = password;
			this.carRegNo = carRegNo;
			this.mobnum = mobnum;
			this.resadd = resadd;
			this.role = role;
			this.freq=freq;
		}
		public User() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		

}
