package entity;

public class spots {

	private int id;
	private String spot;
	private int parkingSpace;
	private String description;
	private String pdate;
	private int pph;
	
	public spots() {
		super();
		// TODO Auto-generated constructor stub
	}
	public spots(int id,String spot, int parkingSpace, String description, String pdate, int pph) {
		super();
		this.id=id;
		this.spot = spot;
		this.parkingSpace = parkingSpace;
		this.description = description;
		this.pdate = pdate;
		this.pph=pph;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSpot() {
		return spot;
	}
	public void setSpot(String spot) {
		this.spot = spot;
	}
	public int getParkingSpace() {
		return parkingSpace;
	}
	public void setParkingSpace(int parkingSpace) {
		this.parkingSpace = parkingSpace;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	
	public int getpph() {
		return pph;
	}
	public void setpph(int pph) {
		this.pph = pph;
	}
	
	
}
