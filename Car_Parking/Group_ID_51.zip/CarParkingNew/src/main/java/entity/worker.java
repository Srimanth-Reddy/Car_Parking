package entity;

public class worker {

	private int id;
	private String name;
	private String specialized;
	private String description;
	private String pdate;
	private int rating;
	
	public worker() {
		super();
		// TODO Auto-generated constructor stub
	}
	public worker(int id,String name, String specialized, String description, String pdate, int rating) {
		super();
		this.id=id;
		this.name = name;
		this.specialized = specialized;
		this.description = description;
		this.pdate = pdate;
		this.rating=rating;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSpecialized() {
		return specialized;
	}
	public void setSpecialized(String specialized) {
		this.specialized = specialized;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	
	
}
