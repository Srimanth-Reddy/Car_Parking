package login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import entity.User;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class loginGoogleServlet
 */
public class loginGoogleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public loginGoogleServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname=request.getParameter("uname");
	
		String mobnum=request.getParameter("mobnum");
		
		String email=request.getParameter("email");
		HttpSession session=request.getSession();
		
		PreparedStatement stmt;
		ResultSet rs;
		Connection con;
		User u=new User();
		RequestDispatcher rd;
		int count=0;
		try{
			session.setAttribute("userobj", u);
			u.setRole("user");
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/carparking","root","root");
			String sql="select * from loginnew where mobileNumber=?";
			stmt=con.prepareStatement(sql);
			stmt.setString(1, mobnum);
			rs=stmt.executeQuery();
			request.setAttribute("userobj.role","user");
			
			
			while(rs.next()){
				if(email.equals(rs.getString("email"))){
					count=1;
					break;
				}
			}
			
			if(count==1){
				request.setAttribute("status","Login Succesfull as "+uname);
				rd=request.getRequestDispatcher("userHome.jsp");
				rd.forward(request, response);
				count=0;
			}
			else{
				request.setAttribute("status","	Invalid credentials entered!");
				request.setAttribute("uuname",uname);
				rd=request.getRequestDispatcher("successlogin.jsp");
				rd.forward(request, response);
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

}
