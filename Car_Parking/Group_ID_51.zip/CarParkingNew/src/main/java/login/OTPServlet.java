package login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class otpServlet
 */
public class OTPServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String otpEntered=request.getParameter("otpid");
		
		RequestDispatcher rd;
		PreparedStatement stmt;
		Connection con;
		ResultSet rs;
		int count=0;
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/carparking","root","root");
			stmt=con.prepareStatement("select otp from otpverify", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs=stmt.executeQuery();
			rs.next();
			if(otpEntered.equals(rs.getString("otp"))){
				count=1;
			}
			
			String realOTP=rs.getString("otp");
			stmt=con.prepareStatement("delete from otpverify where otp='"+realOTP+"'");
			stmt.executeUpdate();
			
			if(count==1){
				request.setAttribute("status","Phone number verified!! ");
				rd=request.getRequestDispatcher("login.jsp");
				rd.forward(request, response);
				count=0;
			}
			else{
				stmt=con.prepareStatement("delete from loginnew where otp='"+realOTP+"'");
				stmt.executeUpdate();
				request.setAttribute("status","Incorrect OTP Entered! Failed to sign up! Please try again. ");
				rd=request.getRequestDispatcher("signup.jsp");
				rd.forward(request, response);
			}
		} 
		
		catch (Exception e){
			e.printStackTrace();
		}
	}
}
