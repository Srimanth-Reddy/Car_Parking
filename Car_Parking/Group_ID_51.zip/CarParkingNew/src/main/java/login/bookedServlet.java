package login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import entity.User;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import promocode.procod;
import promocode.sendProCod;


/**
 * Servlet implementation class bookedServlet
 */
public class bookedServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public bookedServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mobnum=request.getParameter("mobnum");
		String frequency=request.getParameter("freq");
		
		String entrynum=request.getParameter("entrynum");
		String spot=request.getParameter("spot");
		String space=request.getParameter("space");
		String desc=request.getParameter("desc");
		String pph=request.getParameter("pph");
		
		frequency=frequency+0;
		
		try{
			
			PreparedStatement stmt,stmt1,stmt2,stmt3,stmt4,stmt5,stmt6,stmt7;
			Connection con;
			ResultSet rs,rs1;
			RequestDispatcher rd;
			HttpSession session=request.getSession();
			User u=new User();
			u.setRole("user");
			session.setAttribute("userobj", u);
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/carparking","root","root");
			String sql="update loginnew set frequency=? where mobileNumber=?";
			String sql1="select * from loginnew";
			String sql2="insert into promocode(mobileNumber,promo) values(?,?)";
			String sql3="insert into spotbooked(EntryNumber,spotName,spaceavail,description,priceperhour) values(?,?,?,?,?)";
			String sql4="insert into billgeneration(mobnum) values(?)";
			String sql5="select * from spots where EntryNumber=?";
			stmt5=con.prepareStatement(sql5);
			stmt5.setString(1, entrynum);
			rs1=stmt5.executeQuery();
			while(rs1.next()) {
				if(Integer.parseInt(rs1.getString("spaceavail"))!=0) {
					int temp=Integer.parseInt(rs1.getString("spaceavail"));
					String sql6="update spots set spaceavail=? where EntryNumber=?";
					stmt6=con.prepareStatement(sql6);
					stmt6.setString(1, String.valueOf(--temp));
					stmt6.setString(2, entrynum);
					stmt6.executeUpdate();
				
				}
				else {
					String sql6="delete from spots where EntryNumber=?";
					stmt6=con.prepareStatement(sql6);
					stmt6.setString(1, entrynum);
					stmt6.executeUpdate();
				}
			}
			stmt=con.prepareStatement(sql);
			stmt1=con.prepareStatement(sql1);
			stmt.setString(1, frequency);
			stmt.setString(2, mobnum);
			stmt.executeUpdate();
			
			stmt3=con.prepareStatement(sql3);
			stmt3.setString(1, entrynum);
			stmt3.setString(2, spot);
			stmt3.setString(3, space);
			stmt3.setString(4, desc);
			stmt3.setString(5, pph);
			stmt3.executeUpdate();
			
			stmt4=con.prepareStatement(sql4);
			stmt4.setString(1, mobnum);
			stmt4.executeUpdate();
			
			rs=stmt1.executeQuery();
			while(rs.next()) {
				u.setFname(rs.getString("firstname"));
				u.setLname(rs.getString("lastname"));
				u.setUname(rs.getString("username"));
				u.setResadd(rs.getString("residentialAddress"));
				u.setMobnum(rs.getString("mobileNumber"));
				u.setCarRegNo(rs.getString("carRegNum"));
				u.setEmail(rs.getString("email"));
				u.setPassword(rs.getString("password"));
				u.setfreq("frequency");
			}
			
			if(frequency.length()>5) {
				procod pc=new procod();
				String pcmessage=pc.generatepromoCode();
				
//				sendProCod spc=new sendProCod();
//				spc.SendProCod(pcmessage,mobnum);
				
				stmt2=con.prepareStatement(sql2);
				stmt2.setString(1, mobnum);
				stmt2.setString(2, pcmessage);
				stmt2.executeUpdate();
			}
			
			
				rd=request.getRequestDispatcher("afterBooking.jsp");
				rd.forward(request, response);
			
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

}
