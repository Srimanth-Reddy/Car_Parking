package login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class signUpGoogleServlet
 */
public class signUpGoogleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public signUpGoogleServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname=request.getParameter("uname");
		String lname=request.getParameter("uname");
		String uname=request.getParameter("uname");
		String resadd=request.getParameter("resadd");
		String mobnum=request.getParameter("mobnum");
		String carnum=request.getParameter("carnum");
		String email=request.getParameter("email");
		
		PreparedStatement stmt1;
		Connection con;
		RequestDispatcher rd;
		
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/carparking","root","root");
			String sql1="insert into loginnew(firstname,lastname,username,residentialAddress,mobileNumber,carregNum,email,frequency) values(?,?,?,?,?,?,?,?)";
			
			stmt1=con.prepareStatement(sql1);
			stmt1.setString(1,fname);
			stmt1.setString(2,lname);
			stmt1.setString(3,uname);
			stmt1.setString(4,resadd);
			stmt1.setString(5,mobnum);
			stmt1.setString(6,carnum);
			stmt1.setString(7,email);
			stmt1.setString(8, "0");
			stmt1.executeUpdate();
			
			request.setAttribute("status","Registered Successfully as "+uname);
			rd=request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
			
		} 
		catch (Exception e){
			e.printStackTrace();
		}
	}

}
