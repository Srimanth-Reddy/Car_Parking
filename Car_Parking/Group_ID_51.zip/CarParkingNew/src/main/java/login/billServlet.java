package login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.util.*;

import billMsg.billsendmsg;
import dao.SpotDao;
import db.DBConnect;
import entity.spots;

import java.text.*;
/**
 * Servlet implementation class billServlet
 */
public class billServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public billServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SpotDao dao=new SpotDao(DBConnect.getConn());
		spots s=dao.getSpotBooked();

		String checkintime=request.getParameter("checkintime");
		String checkouttime=request.getParameter("checkouttime");
		RequestDispatcher rd;
		ResultSet rs,rs1;
		
		
		try {
			Connection con;
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/carparking","root","root");
			PreparedStatement stmt,stmt1,stmt2,stmt3;
			String sql="insert into billgeneration(bill,othbill) values(?,?)";
			String sql1="select * from billgeneration";
			String sql3="delete from spots where spaceavail=?";
			stmt=con.prepareStatement(sql);
			stmt1=con.prepareStatement(sql1);
			stmt3=con.prepareStatement(sql3);
			stmt3.setString(1, "0");
			stmt3.executeUpdate();
			rs=stmt1.executeQuery();
			String mobnum = null;
			while(rs.next()) {
				mobnum=rs.getString(1);
			}
			
					String time1 = checkintime;
					String time2 = checkouttime;

					SimpleDateFormat simpleDateFormat
					= new SimpleDateFormat("HH:mm");

				// Parsing the Time Period
				Date date1 = simpleDateFormat.parse(time1);
				Date date2 = simpleDateFormat.parse(time2);

				// Calculating the difference in milliseconds
				long differenceInMilliSeconds
					= Math.abs(date2.getTime() - date1.getTime());

				// Calculating the difference in Hours
				long differenceInHours
					= (differenceInMilliSeconds / (60 * 60 * 1000))
					% 24;

				// Calculating the difference in Minutes
				long differenceInMinutes
					= (differenceInMilliSeconds / (60 * 1000)) % 60;

				String difference;
				// Printing the answer
				if(differenceInHours<10) {
					difference="0"+differenceInHours+":";
				}
				else {
					difference=differenceInHours+":";
				}
				if(differenceInMinutes<10) {
					difference=difference+"0"+differenceInMinutes;
				}
				else {
					difference=difference+differenceInMinutes;
				}
				
				double bill= (double)((double)differenceInHours+(double)(differenceInMinutes/60.0))*(double)s.getpph();
				
				Random random=new Random();
				
				String othbill=String.valueOf(random.nextInt(10000));
				
				stmt.setString(1, String.valueOf(bill));
				stmt.setString(2, othbill);
				stmt.executeUpdate();
//				billsendmsg bsm=new billsendmsg();
//				bsm.sendbillasmsg(String.valueOf(bill), othbill, mobnum);
			
				
			String sql2="truncate table billgeneration";
			stmt2=con.prepareStatement(sql2);
			stmt2.executeUpdate();
			
			
			rd=request.getRequestDispatcher("Rating.jsp");
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
