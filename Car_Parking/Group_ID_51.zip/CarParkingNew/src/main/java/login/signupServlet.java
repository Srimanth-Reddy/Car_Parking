package login;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import otp.OTP;
import otp.sendOTP;
//@WebServlet("/signupServlet")
public class signupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;   
    public signupServlet() {
    	super();
    }

	/**

	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)

	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.getWriter().append("Served at: ").append(request.getContextPath());
    }

	/**

	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)

	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException         {
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String uname=request.getParameter("uname");
		String resadd=request.getParameter("resadd");
		String mobnum=request.getParameter("mobnum");
		String carnum=request.getParameter("carnum");
		String email=request.getParameter("email");
		String pass=request.getParameter("pass");
		
		PreparedStatement stmt1,stmt2;
		Connection con;
		RequestDispatcher rd;
		
		OTP otp=new OTP();
		String otpmessage=otp.generateOTP(6);
		
		sendOTP sotp=new sendOTP();
		sotp.SendOTP(otpmessage,mobnum);
		
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/carparking","root","root");
			String sql1="insert into loginnew(firstname,lastname,username,residentialAddress,mobileNumber,carregNum,email,password,otp,frequency) values(?,?,?,?,?,?,?,?,?,?)";
			String sql2="insert into otpverify(mobileNumber,otp) values(?,?)";
			
			stmt1=con.prepareStatement(sql1);
			stmt1.setString(1,fname);
			stmt1.setString(2,lname);
			stmt1.setString(3,uname);
			stmt1.setString(4,resadd);
			stmt1.setString(5,mobnum);
			stmt1.setString(6,carnum);
			stmt1.setString(7,email);
			stmt1.setString(8,pass);
			stmt1.setString(9,otpmessage);
			stmt1.setString(10, "0");
			stmt1.executeUpdate();
			
			stmt2=con.prepareStatement(sql2);
			stmt2.setString(1, mobnum);
			stmt2.setString(2, otpmessage);
			stmt2.executeUpdate();
			
			rd=request.getRequestDispatcher("phoneVerify.jsp");
			rd.forward(request, response);
			
		} 
		catch (Exception e){
			e.printStackTrace();
		}
	}
}