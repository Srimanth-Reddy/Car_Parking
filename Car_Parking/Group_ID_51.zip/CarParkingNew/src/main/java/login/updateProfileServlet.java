package login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import entity.User;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


/**
 * Servlet implementation class updateProfileServlet
 */
public class updateProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public updateProfileServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			
			String uname=request.getParameter("uname");
			String resadd=request.getParameter("resadd");
			String mobnum=request.getParameter("mobnum");
			String carnum=request.getParameter("carnum");
			String email=request.getParameter("email");
			String mobnumnew=request.getParameter("mobnumnew");
			String pass=request.getParameter("pass");
			
			PreparedStatement stmt;
			HttpSession session=request.getSession();
			User u=new User();
			u.setRole("user");
			session.setAttribute("userobj", u);
			Connection con;
			RequestDispatcher rd;
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/carparking","root","root");
			String sql="update loginnew set username=?,residentialAddress=?,mobileNumber=?,carregNum=?,email=?,password=? where mobileNumber=?";
			stmt=con.prepareStatement(sql);
			stmt.setString(1, uname);
			stmt.setString(2, resadd);
			stmt.setString(3, mobnumnew);
			stmt.setString(4, carnum);
			stmt.setString(5, email);
			stmt.setString(6, pass);
			stmt.setString(7, mobnum);
			stmt.executeUpdate();
			
			
			u.setUname(uname);
			u.setResadd(resadd);
			u.setMobnum(mobnumnew);
			u.setCarRegNo(carnum);
			u.setEmail(email);
			u.setPassword(pass);
			
			
				rd=request.getRequestDispatcher("userHome.jsp");
				rd.forward(request, response);
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
